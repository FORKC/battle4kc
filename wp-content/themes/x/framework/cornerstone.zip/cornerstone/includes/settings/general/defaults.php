<?php

return array(

	'custom_css' => '',
	'custom_js'  => '',
	'post_title'     => 'Cornerstone Draft',
	'post_status'    => 'draft',
	'allow_comments' => false,
	'post_parent'    => '0',
	'page_template'  => 'default',
	'manual_excerpt' => '',

);
