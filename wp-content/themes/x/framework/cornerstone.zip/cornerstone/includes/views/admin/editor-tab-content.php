<div class="cs-editor-container <?php e_csi18n('admin.integration-mode') ?>">
  <div class="cs-logo"><?php $this->view( csi18n('admin.editor-tab-logo-path') ); ?></div>
  <button href="#" data-cs-edit-button class="cs-edit-btn">
    <span><?php e_csi18n('admin.edit-with-cornerstone'); ?></span>
  </button>
</div>
