<?php

return array(
  'advanced_mode'          => false,
  'dynamic_content'        => false,
  'control_nav'            => 'inline',
  'help_text'              => true,
  'show_wp_toolbar'        => false,
  'rich_text_default'      => false,
  'context_menu'           => true,
  'ui_theme'               => 'light',
  'content_layout_element' => 'layout-row',
  'custom_app_css'         => ''
);
